<?php 
return array (
  'APP_STATE' => 0,
  'APP_NAME' => '数据采集',
  'APP_VER' => '1.0.2015.0803',
  'APP_AUTHOR' => '路过',
  'APP_ORIGINAL_PREFIX' => 'yx_',
  'APP_TABLES' => 'collectrules',
);