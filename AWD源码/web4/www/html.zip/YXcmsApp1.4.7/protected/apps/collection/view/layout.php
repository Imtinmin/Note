<?php if(!defined('APP_NAME')) exit;?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="__PUBLIC__/admin/css/back.css" />
<script type="text/javascript" src="__PUBLIC__/js/jquery.js"></script>
<title>信息采集</title>
</head>
<body>
{include file="$__template_file"}
</body>
</html>