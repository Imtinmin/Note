<?php
return array (
  'APP_STATE' => 1,
  'APP_NAME' => '示例页面',
  'APP_VER' => '1.0.2012.0820',
  'APP_AUTHOR' => '路过',
  'APP_ORIGINAL_PREFIX' => '',
  'APP_TABLES' => '',
);