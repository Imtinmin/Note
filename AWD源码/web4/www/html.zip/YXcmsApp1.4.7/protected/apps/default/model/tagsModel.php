<?php
class tagsModel extends baseModel{
	protected $table = 'tags';
}