<?php
include('../safe.php');
$hhh=new Ha;
$hhh -> ha();
?>
