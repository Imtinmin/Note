<?php defined('IN_MET') or exit('No permission'); ?>
<include file="head.php" />
<section class="met-feedback animsition" m-id="feedback" m-type='noset'>
    <div class="container">
        <div class="row">
            <div class="met-feedback-body">
                <tag action='feedback.form'></tag>
                </div>
        </div>
    </div>
</section>
<include file="foot.php" />