<?php
# MetInfo Enterprise Content Management System
# Copyright (C) MetInfo Co.,Ltd (http://www.metinfo.cn). All rights reserved.

defined('IN_MET') or exit('No permission');

/**
 * 网站地图标签类
 */

class site_label {
  /**
	 * 获取网站地图数组
	 * @param  string  $lang 当前语言
	 * @return array         网站地图数组
	 */
	public function get_sitemap($lang = ''){
		global $_M;
		
  }
}

# This program is an open source system, commercial use, please consciously to purchase commercial license.
# Copyright (C) MetInfo Co., Ltd. (http://www.metinfo.cn). All rights reserved.
?>
