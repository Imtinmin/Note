$(document).ready(function()
{          
    // add "index" class to the body element.
    $('body').addClass('index');

    $('.nav-system-home:first').addClass('active');
})
