$(document).ready(function()
{
    $.setAjaxForm('#bindForm, #registerForm');
})
