$(document).ready(function()
{
    $.setAjaxForm('#registerForm');
    $.setAjaxForm('#bindForm');
});
