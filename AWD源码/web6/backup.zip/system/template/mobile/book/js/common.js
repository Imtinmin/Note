$(document).ready(function()
{
    if(v.fullScreen)
    {
        $('body').css('margin', '0');
        $('body').css('padding', '0');
    }
});
