{if(!defined("RUN_MODE"))} {!die()} {/if}
<div class='article-content'>
  {!htmlspecialchars_decode($control->config->site->agreementContent)}
</div>
