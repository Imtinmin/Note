{if(!defined("RUN_MODE"))} {!die()} {/if}
{include $model->loadModel('ui')->getEffectViewFile('mobile', 'block', 'articletree')}
