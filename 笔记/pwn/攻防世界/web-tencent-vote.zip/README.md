# 腾讯-面试代码-在线投票

## Question

实现一个投票程序，要求能实时把投票结果显示在大屏幕上，有2个页面，投票页面，显示结果的页，应用场景，发起方把链接公布在活动场景的二维码上，当时参加活动的人大约有3000-5000人左右。

## Answer

- 实现方案
    - Web
- 功能点
    - [x] 实时大屏显示投票信息
        -  Websocket
    - [x] 投票二维码生成
    - [ ] 会话保持
- 优化
    - [x] 限制允许一次投票（可配置）
        - Hash Unique
        - IP Unique
    - [ ] 界面优化
    - [ ] 投票项目可设置
        为了节省时间，采用JSON配置投票信息。
    - [ ] 添加投票后台，支持多种项目投票

## 实现逻辑

- 投票页
    - **前端** 静态页面（适配手机投票），点击投票后写入数据库
    - **后端** 
        - 写入SQLite数据库，IP,HASH,投票项目,时间
        - 通过 Websocket 推送投票数据到 **显示大屏**
- 大屏显示（适配PC大屏显示）
    - **前端** 
        - 链接 websocket
        - 读取后台初始数据

## 技术栈

因为使用Php实现Websocket比较麻烦，需要手动（PS：我自己以前实现过，代码找不到了），所以采用如下技术实现

- Python 3.x
    - Tornado 
        - 高并发支持
        - Websocket 服务器支持
    - python-qrcode
        二维码生成
- Javascript
    - fetch 异步请求
    - websocket 同步

##  使用

- 配置config.yml 参数
    - server: 为外部服务器IP和端口
    - votes: 投票选项
- 运行：

```
python3 main.py
```

## 测试

![](vote-python.gif)

## Bug

- 异步请求未带Cookie导致Session模式可重复投票（限制Session模式失败）
    解决方案：
    - 采用 `withCredentials`
    - 采用手动Session配置

## 优化

- Websocket 和 Ajax 支持跨域访问


## 关于

- HTML模板引擎：自制：https://github.com/dxkite/dxtpl
- 跨域解决方案：http://www.atd3.cn/52