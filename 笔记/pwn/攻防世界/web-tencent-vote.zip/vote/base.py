import tornado.web
from vote.models import db,Votes
import hashlib
import time
from sqlalchemy import and_

class BaseHandler(tornado.web.RequestHandler):

    session_id =None

    @property
    def orm(self):
        return db()

    def on_finish(self):
        db.remove()

    def get_session_id(self):
        if self.session_id == None:
            if self.get_secure_cookie('session') != None:
                self.session_id = self.get_secure_cookie('session')
            else:
                self.session_id = self.get_md5('%s%s' % ( time.time(), self.request.remote_ip ))
                self.set_secure_cookie('session', self.session_id, expires_days=1)
        return self.session_id

    def get_md5(self, code):
        md5 = hashlib.md5()   
        md5.update(code.encode('utf-8'))   
        return md5.hexdigest().encode('utf-8')

    '''判断是否可以投票'''
    def is_voted(self):
        addr_hash = self.get_md5(self.request.remote_ip)
        session_hash = self.get_session_id()
        print('session %s'%self.get_session_id())
        if self.application.get_config()['unique'] == 'ip': # 限制IP
            return db().query(Votes.id).filter(Votes.addr_hash == addr_hash).first() != None
        elif self.application.get_config()['unique'] == 'session': # 限制会话
            return db().query(Votes.id).filter(Votes.session_hash == session_hash).first() != None
        elif self.application.get_config()['unique'] == 'session+ip': # 双重限制
            return db().query(Votes.id).filter(and_(Votes.session_hash == session_hash, Votes.addr_hash == addr_hash)).first() != None
        else:
            return False
        

            