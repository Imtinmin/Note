from sqlalchemy import Column
from sqlalchemy.dialects.sqlite import FLOAT, VARCHAR, INTEGER
from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import func
from vote.settings import connect_str

import json

BaseModel = declarative_base()
engine = create_engine(connect_str, echo=True, pool_recycle=3600)
db = scoped_session(sessionmaker(bind=engine))


class Votes(BaseModel):
    __tablename__ ='votes'
    id = Column(INTEGER, primary_key=True, autoincrement=True)
    vote = Column(INTEGER, index = True)
    addr_hash = Column(VARCHAR(32))
    session_hash = Column(VARCHAR(32))
    
    '''获取投票详情'''
    @staticmethod
    def get_votes(config):
        data = db().query(Votes.vote, func.count(Votes.vote)).group_by(Votes.vote).all()
        ret = []
        for item in config:
            vote = item
            votes = Votes.__get_data(data, item['unique'])
            vote['votes'] = votes
            ret.append(vote)
        return ret

    '''给某人投票'''
    @staticmethod
    def vote_to(unique, session, ip):
        vote = Votes(vote=unique, addr_hash = ip, session_hash = session)
        db().add(vote)
        db().commit()
        return vote.id > 0

    @staticmethod
    def __get_data(data, index):
        for item in data:
            if item[0] == index:
                return item[1]
        return 0

    def __repr__(self):
        return json.dumps({
            'id' : self.id,
            'vote' : self.vote,
            'addr': self.addr_hash,
            'session': self.session_hash, 
        })

