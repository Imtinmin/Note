import os
import tornado.web
import yaml
import json

from vote.controller import routes
from vote.settings import debug, cookie_secret, vote_config_path, static_path
from vote.models import Votes

class Application(tornado.web.Application):
    vote_config = None
    ws = set()

    def __init__(self):
        self.root_path = os.path.dirname(__file__)
        settings = dict(
            static_path=static_path,
            template_path=os.path.join(self.root_path, 'template'),
            cookie_secret=cookie_secret,
            debug=debug,
        )
        super(Application, self).__init__(routes, **settings)

    def get_config(self):
        if self.vote_config is None:
            with open(vote_config_path, 'r', encoding='utf-8') as f:
                ymldata = f.read()
                self.vote_config = yaml.load(ymldata)
                if self.vote_config['secure'] :
                    self.vote_config['web'] = 'https://%s' % self.vote_config['server']
                    self.vote_config['websocket'] = 'wss://%s' % self.vote_config['server']
                else:
                    self.vote_config['web'] = 'http://%s' % self.vote_config['server']
                    self.vote_config['websocket'] = 'ws://%s' % self.vote_config['server']
                
        return self.vote_config
    
    def set_ws(self, ws):
        self.ws.add(ws)
    
    '''广播'''
    def send_votes(self):
        message = json.dumps(Votes.get_votes(self.get_config()['votes']))
        for ws in self.ws:
            if not ws.closed:
                ws.write_message(message)
