import os

debug = True
db_path = os.path.join(os.getcwd(), 'votes.db3')
vote_config_path = os.path.join(os.getcwd(), 'config.yml')
connect_str = 'sqlite:///%s' % db_path
cookie_secret = 'VmpKMGIySXlUblJTYkd4V1lsaGpPUT09'
static_path=os.path.join(os.path.dirname(__file__), 'template/static')