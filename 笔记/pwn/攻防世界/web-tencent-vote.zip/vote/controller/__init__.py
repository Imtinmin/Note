from vote.controller.Main import *
from vote.controller.Error import *

routes = [
    (r"/", MainHandler),
    (r"/vote", VoteHandler),
    (r"/vote/api", VoteJsonHandler),
    (r"/main", MainWebSocketHandler),
    (r".*", Error404Handler),
]