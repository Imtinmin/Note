import tornado.web
import tornado.websocket
import json
from vote.base import BaseHandler
from vote.models import Votes


'''投票大屏显示'''
class MainHandler(tornado.web.RequestHandler):
    def get(self):
        setting = self.application.get_config()
        votes = Votes.get_votes(setting['votes'])
        self.render('main.html', votes = votes, setting = setting)

'''投票页面显示'''
class VoteHandler(BaseHandler):
    def get(self):
        setting = self.application.get_config()
        votes = Votes.get_votes(setting['votes'])
        voted = self.is_voted()
        self.render('vote.html', votes = votes, setting = setting, voted = voted)

'''投票API导出'''
class VoteJsonHandler(BaseHandler):

    def set_default_headers(self):
        self.set_header('Access-Control-Allow-Origin', '*')
        self.set_header('Access-Control-Allow-Methods', 'POST, GET')
        self.set_header('Access-Control-Max-Age', 1000)
        self.set_header('Access-Control-Allow-Headers', '*')
        self.set_header('Content-type', 'application/json')

    '''获取投票信息'''
    def get(self):
        voted = self.is_voted()
        data = Votes.get_votes(self.application.get_config()['votes'])
        self.write(json.dumps({
            'is_vote': voted,
            'votes': data,
        }))

    '''给某个人投票'''
    def post(self):
        if self.is_voted() :
            self.write(json.dumps({
                'error': 1,
                'message' : 'is voted'
            }))
        else:
            ret = Votes.vote_to(self.get_argument('vote_id'), self.get_session_id(), self.get_md5(self.request.remote_ip))
            self.write(json.dumps({'result': ret}))
            self.application.send_votes()


'''大屏同步广播'''
class MainWebSocketHandler(tornado.websocket.WebSocketHandler):
    
    closed = False

    def open(self):
        self.application.set_ws(self)   
        self.application.send_votes()

    def on_message(self, message):
        print(message)

    def on_close(self):
        self.closed = True
