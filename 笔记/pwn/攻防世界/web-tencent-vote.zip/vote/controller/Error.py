import tornado.web

class Error404Handler(tornado.web.RequestHandler):
    def get(self):
        self.render('404.html')