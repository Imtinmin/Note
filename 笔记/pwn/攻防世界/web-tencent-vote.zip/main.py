import tornado.ioloop
import tornado.web
import tornado.httpserver
import tornado.options
from tornado.options import options, define
from vote import Application
from vote.settings import db_path, static_path
import os
from vote.models import BaseModel, engine
import qrcode 

define('port', default=8888, help='run on the given port', type=int)
define('address', default='0.0.0.0',
       help='binding at given address', type=str)




''' 创建本地投票数据库 '''
def create_db_if_not_exists():
    if not os.path.exists(db_path):
        BaseModel.metadata.create_all(engine)
        print('create sqlite db to %s' % db_path)

def gen_qrcode(qrcode_link):
    qrcode_path = os.path.join(static_path, 'qrcode.png')
    qr = qrcode.QRCode(     
        version=1,     
        error_correction=qrcode.constants.ERROR_CORRECT_L,     
        box_size=10,     
        border=4, 
    ) 
    qr.add_data(qrcode_link) 
    qr.make(fit=True)  
    img = qr.make_image()
    img.save(qrcode_path)

def main():
    tornado.options.parse_command_line()
    create_db_if_not_exists()
    application = Application()
    gen_qrcode(application.get_config()['server']+'/vote')
    server = tornado.httpserver.HTTPServer(application)
    server.listen(options.port, options.address)
    print('server started: <http://%s:%s>' % (options.address, options.port))
    tornado.ioloop.IOLoop.instance().start()
    
if __name__ == "__main__":
    main()
